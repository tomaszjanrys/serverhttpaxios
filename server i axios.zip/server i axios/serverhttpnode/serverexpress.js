const http = require('http');
let fs = require('fs')
const { url } = require('inspector');
const path = require('path')
const port = 1111
const myJson = {
    "employees": [
        { "firstName": "John", "lastName": "Doe" },
        { "firstName": "Anna", "lastName": "Smith" },
        { "firstName": "Peter", "lastName": "Jones" }
    ],
    "cars": [
        { "model": "Fiat", "speed": "95 km/h" },
        { "model": "Trabant", "speed": "45 km/h" },
        { "model": "Porshe", "speed": "320 km/h" }
    ]
}
const server = http.createServer((request, response) => {
    if (request.url === '/') {
        fs.readFile("./public/index.html", "UTF-8", (err, html) => {
            response.writeHead(200, { "Content-Type": "text/html" });
            response.end(html)
        })

    } else if (request.url.match("\.css$")) {
        let cssPath = path.join(__dirname, 'public', request.url)
        let fileStream = fs.createReadStream(cssPath, "UTF-8");
        response.writeHead(200, { "Content-Type": "text/css" })
        fileStream.pipe(response)
    } else if (request.url.match("\.jpg$")) {
        let imagesPath = path.join(__dirname, 'public', request.url)
        let fileStream = fs.createReadStream(imagesPath);
        response.writeHead(200, { "Content-Type": "image/jpg" })
        fileStream.pipe(response)
    } else if (request.url === '/tomek') {
        response.write(JSON.stringify(myJson)) //wyswietla jsona na stronie
        response.end()
    } else {
        response.writeHead(400, { "Content-Type": "text/html" });
        response.end("NIe ma takiej strony .....................;(")
    }

});
server.listen(port, (err) => {
    if (err) {
        console.log('cos poszlo nie tak')
    }
    console.log('Serwer uruchominy....')
})
server.on('connection', (socet) => {
        console.log('nowe polaczenie')
    })
    //*****************************Wylaczenie servera********************************* */
    //zamkniecie srwera
    //setTimeout(() => {
    //      server.close()
    // }, 5000)
    //end
    //************************************************************* */