const axios = require('axios')
const instance = axios.create({
    baseURL: 'http://localhost:1111/',
    responseType: 'json',
});
instance.get('tomek', {

    })
    .then(function(response) {
        console.log("****EMPLOYEES****")
        console.log(response.data.employees[1]);
        console.log("****CARS****")
        console.log(response.data.cars);
    })
    .catch(function(error) {
        console.log(error);
    })